# Release der Makefiles

- Stelle sicher, dass du auf dem develop-Branch bist
- Starte den Release mit `make makefiles-release`
